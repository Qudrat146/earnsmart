(() => {
  const $ = id => document.getElementById(id);
  let token = sessionStorage.getItem("earnsmart_token") || "";
  let config = null, user = null, currentSlot = null, rewardGranted = false, adBusy = false;
  const api = async (url, options={}) => {
    const headers = {"Content-Type":"application/json", ...(options.headers||{})};
    if (token) headers.Authorization = "Bearer " + token;
    const response = await fetch(url, {...options, headers});
    const data = await response.json().catch(()=>({error:"د سرور ځواب لوستل کېدای نه شول."}));
    if (!response.ok) throw new Error(data.error || "غوښتنه ناکامه شوه.");
    return data;
  };
  function message(id, text, kind="") {
    const el=$(id); el.textContent=text; el.className="status "+kind;
  }
  function authMessage(text, kind="") { $("authMsg").textContent=text; $("authMsg").className=kind; }
  function setLoggedIn(on) {
    $("authCard").classList.toggle("hidden", on);
    $("logout").disabled=!on;
    $("watch").disabled=!on || !config?.adsConfigured || adBusy;
    $("accountState").textContent=on ? `ننوتل شوی: ${user?.email || ""}` : "لا ننوتل شوی نه دی.";
  }
  async function refreshMe() {
    if (!token) { user=null; setLoggedIn(false); $("points").textContent="0"; $("history").textContent="د تاریخچې لپاره حساب ته ننوځه."; return; }
    try {
      const data=await api("/api/me"); user=data.user;
      $("points").textContent=user.points;
      $("accountState").textContent=`ننوتل شوی: ${user.email}`;
      $("history").innerHTML = data.history.length ? data.history.map(x=>{
        const row=document.createElement("div"); row.className="hist";
        const title=document.createElement("span"); title.textContent=x.reason;
        const points=document.createElement("strong"); points.className="green"; points.textContent=`+${x.points} PTS`;
        row.append(title,points); return row.outerHTML;
      }).join("") : "تر اوسه انعام نشته.";
      setLoggedIn(true);
    } catch(e) {
      token=""; sessionStorage.removeItem("earnsmart_token"); user=null; setLoggedIn(false);
      authMessage(e.message);
    }
  }
  async function authenticate(which) {
    const email=$("email").value.trim(), password=$("password").value;
    try {
      const data=await api("/api/"+which,{method:"POST",body:JSON.stringify({email,password})});
      token=data.token; sessionStorage.setItem("earnsmart_token",token);
      authMessage(which==="register"?"حساب جوړ شو.":"ننوتل بریالي شول.");
      await refreshMe();
      $("watch").disabled=!config?.adsConfigured;
    } catch(e) { authMessage(e.message,"error"); }
  }
  $("register").addEventListener("click",()=>authenticate("register"));
  $("login").addEventListener("click",()=>authenticate("login"));
  $("logout").addEventListener("click",()=>{token="";user=null;sessionStorage.removeItem("earnsmart_token");refreshMe();message("adStatus","له حسابه ووتلې.");});
  $("adConsent").addEventListener("change",()=>{ $("watch").disabled=!token || !config?.adsConfigured || !$("adConsent").checked || adBusy; });

  async function startRewardedAd() {
    if (!token || !config?.adsConfigured || !$("adConsent").checked || adBusy) return;
    if (!window.googletag || !googletag.cmd) {
      message("adStatus","د Google اعلان کتابتون نه دی پورته شوی. انعام نه دی ورکړل شوی.","error"); return;
    }
    adBusy=true; $("watch").disabled=true; rewardGranted=false;
    message("adStatus","د اعلان د موجودیت کتنه روانه ده…");
    let rewardSession;
    try {
      rewardSession=await api("/api/reward-sessions",{method:"POST",body:"{}"});
    } catch(e) {
      adBusy=false; $("watch").disabled=false; message("adStatus",e.message,"error"); return;
    }
    googletag.cmd.push(() => {
      let slot=null;
      try {
        slot=googletag.defineOutOfPageSlot(config.rewardedAdUnitPath, googletag.enums.OutOfPageFormat.REWARDED);
        if (!slot) {
          adBusy=false; $("watch").disabled=false;
          message("adStatus","دا پاڼه/وسیله د Rewarded Ad ملاتړ نه کوي. انعام نه دی ورکړل شوی.","error"); return;
        }
        currentSlot=slot;
        slot.addService(googletag.pubads());
        const onReady = event => {
          if (event.slot !== slot) return;
          message("adStatus","اعلان چمتو دی. که غواړې، اوس یې وګوره.");
          const shown=event.makeRewardedVisible();
          if (!shown) {
            message("adStatus","اعلان ښکاره نه شو؛ انعام نشته.","error");
          }
        };
        const onGranted = async event => {
          if (event.slot !== slot || rewardGranted) return;
          rewardGranted=true;
          try {
            const result=await api("/api/rewards/claim",{method:"POST",body:JSON.stringify({sessionId:rewardSession.sessionId})});
            message("adStatus",`د اعلان شبکې انعام ورکړ. +${result.pointsAdded} مجازي پوائنټونه اضافه شول. ${result.note}`,"ok");
            await refreshMe();
          } catch(e) {
            message("adStatus","د انعام ثبت ناکام شو: "+e.message,"error");
          }
        };
        const onClosed = event => {
          if (event.slot !== slot) return;
          googletag.pubads().removeEventListener("rewardedSlotReady",onReady);
          googletag.pubads().removeEventListener("rewardedSlotGranted",onGranted);
          googletag.pubads().removeEventListener("rewardedSlotClosed",onClosed);
          googletag.destroySlots([slot]); currentSlot=null; adBusy=false;
          $("watch").disabled=!token || !config?.adsConfigured || !$("adConsent").checked;
          if (!rewardGranted) message("adStatus","اعلان وتړل شو یا انعام ونه منل شو؛ پوائنټونه نه دي ورکړل شوي.");
        };
        googletag.pubads().addEventListener("rewardedSlotReady",onReady);
        googletag.pubads().addEventListener("rewardedSlotGranted",onGranted);
        googletag.pubads().addEventListener("rewardedSlotClosed",onClosed);
        googletag.display(slot);
        message("adStatus","د اعلان غوښتنه ولېږل شوه. که اعلان موجود نه وي، انعام نه ترلاسه کېږي.");
      } catch(e) {
        if (slot) { try{googletag.destroySlots([slot]);}catch(_){} }
        currentSlot=null; adBusy=false; $("watch").disabled=false;
        message("adStatus","د اعلان پیلولو ستونزه: "+e.message,"error");
      }
    });
  }
  $("watch").addEventListener("click",startRewardedAd);

  (async function init(){
    try {
      config=await api("/api/config");
      $("modeBadge").textContent=config.adsConfigured?"د اعلان تنظیم شوی":"د اعلان تنظیم نشته";
      if (!config.adsConfigured) message("adStatus","Rewarded Ads لا نه دي تنظیم شوي. مدیر دې د Ad Manager معلومات په سرور کې واچوي.");
      else message("adStatus","شبکه تنظیم شوې؛ د حساب ننوتل او د اعلان رضایت اړین دي.");
      await refreshMe();
      $("watch").disabled=!token || !config.adsConfigured || !$("adConsent").checked;
      if (config.adsConfigured) {
        window.googletag = window.googletag || {cmd:[]};
        googletag.cmd.push(() => {
          googletag.pubads().disableInitialLoad();
          googletag.pubads().enableSingleRequest();
          googletag.enableServices();
        });
      }
    } catch(e) { message("adStatus","سرور ته اتصال ناکام شو. اپ په Node.js سرور چلوه.","error"); }
  })();
})();