require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "";
const GAM_NETWORK_CODE = (process.env.GAM_NETWORK_CODE || "").trim();
const GAM_REWARDED_AD_UNIT_PATH = (process.env.GAM_REWARDED_AD_UNIT_PATH || "").trim();
const adsConfigured = Boolean(GAM_NETWORK_CODE && GAM_REWARDED_AD_UNIT_PATH);
const db = new Database(process.env.DB_PATH || "earnsmart.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 points INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reward_sessions (
 id TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'issued',
 created_at INTEGER NOT NULL,
 expires_at INTEGER NOT NULL,
 claimed_at INTEGER,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS ledger (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 points INTEGER NOT NULL,
 reason TEXT NOT NULL,
 reference_id TEXT NOT NULL UNIQUE,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://securepubads.g.doubleclick.net", "https://www.googletagservices.com"],
      connectSrc: ["'self'", "https://securepubads.g.doubleclick.net", "https://pubads.g.doubleclick.net"],
      frameSrc: ["'self'", "https://googleads.g.doubleclick.net", "https://tpc.googlesyndication.com"],
      imgSrc: ["'self'", "data:", "https:"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  }
}));
app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false }));

const authLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 10, standardHeaders: true, legacyHeaders: false });
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const clean = (v) => typeof v === "string" ? v.trim() : "";
function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token || !JWT_SECRET || JWT_SECRET.length < 32) return res.status(401).json({ error: "ننوتل شوی نه یې، یا سرور سم تنظیم شوی نه دی." });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = { id: Number(payload.sub) };
    next();
  } catch {
    return res.status(401).json({ error: "د ننوتلو موده ختمه شوې؛ بیا ننوځه." });
  }
}
function publicConfig() {
  return {
    adsConfigured,
    gamNetworkCode: adsConfigured ? GAM_NETWORK_CODE : "",
    rewardedAdUnitPath: adsConfigured ? GAM_REWARDED_AD_UNIT_PATH : "",
    cashWithdrawalsEnabled: process.env.CASH_WITHDRAWALS_ENABLED === "true",
    pointsOnlyNotice: "پوائنټونه د ډیمو/مجازی انعام لپاره دي؛ د واقعي پیسو تضمین نه شته."
  };
}
app.get("/api/config", (_req, res) => res.json(publicConfig()));

app.post("/api/register", authLimiter, async (req, res) => {
  const email = clean(req.body.email).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  if (!emailPattern.test(email) || email.length > 254) return res.status(400).json({ error: "سم ایمېل ولیکه." });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: "پاسورډ باید لږ تر لږه ۱۰ توري ولري." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users(email,password_hash) VALUES(?,?)").run(email, hash);
    const token = jwt.sign({}, JWT_SECRET, { subject: String(info.lastInsertRowid), expiresIn: "7d" });
    res.status(201).json({ token, user: { email, points: 0 } });
  } catch (e) {
    if (String(e.code).startsWith("SQLITE_CONSTRAINT")) return res.status(409).json({ error: "دا ایمېل مخکې ثبت شوی." });
    console.error(e); res.status(500).json({ error: "د حساب جوړولو ستونزه." });
  }
});

app.post("/api/login", authLimiter, async (req, res) => {
  const email = clean(req.body.email).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "ایمېل یا پاسورډ ناسم دی." });
  const token = jwt.sign({}, JWT_SECRET, { subject: String(user.id), expiresIn: "7d" });
  res.json({ token, user: { email: user.email, points: user.points } });
});

app.get("/api/me", auth, (req, res) => {
  const user = db.prepare("SELECT id,email,points,created_at FROM users WHERE id=?").get(req.user.id);
  if (!user) return res.status(404).json({ error: "حساب ونه موندل شو." });
  const history = db.prepare("SELECT points,reason,created_at FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT 10").all(req.user.id);
  res.json({ user, history });
});

/*
 * Important security boundary:
 * GPT rewardedSlotGranted is a browser event, not cryptographic proof for a cash payout.
 * This starter issues a short-lived, one-use session and idempotently credits VIRTUAL points.
 * Do not convert these points to cash until a provider-approved server-side verification,
 * fraud controls, and payout review have been implemented.
 */
app.post("/api/reward-sessions", auth, (req, res) => {
  if (!adsConfigured) return res.status(503).json({ error: "Rewarded Ads لا نه دي تنظیم شوي. لومړی د Ad Manager معلومات په .env کې واچوه." });
  const now = Date.now();
  const recent = db.prepare("SELECT COUNT(*) AS n FROM reward_sessions WHERE user_id=? AND created_at>?").get(req.user.id, now - 60_000).n;
  if (recent >= 1) return res.status(429).json({ error: "لږ انتظار وکړه او بیا هڅه وکړه." });
  const id = crypto.randomUUID();
  db.prepare("INSERT INTO reward_sessions(id,user_id,status,created_at,expires_at) VALUES(?,?,'issued',?,?)")
    .run(id, req.user.id, now, now + 5 * 60_000);
  res.json({ sessionId: id, expiresInSeconds: 300 });
});

app.post("/api/rewards/claim", auth, (req, res) => {
  const sessionId = clean(req.body.sessionId);
  if (!/^[0-9a-f-]{36}$/i.test(sessionId)) return res.status(400).json({ error: "د reward session ناسم ID." });
  const session = db.prepare("SELECT * FROM reward_sessions WHERE id=? AND user_id=?").get(sessionId, req.user.id);
  if (!session) return res.status(404).json({ error: "د انعام session ونه موندل شو." });
  if (session.status !== "issued") return res.status(409).json({ error: "د دې session انعام مخکې پروسس شوی." });
  if (Date.now() > session.expires_at) {
    db.prepare("UPDATE reward_sessions SET status='expired' WHERE id=?").run(sessionId);
    return res.status(410).json({ error: "د انعام session موده ختمه شوې." });
  }
  const POINTS_PER_REWARD = 10; // Virtual points only. Configure only after ad-unit policies are reviewed.
  const tx = db.transaction(() => {
    const changed = db.prepare("UPDATE reward_sessions SET status='claimed',claimed_at=? WHERE id=? AND status='issued'").run(Date.now(), sessionId);
    if (changed.changes !== 1) throw new Error("SESSION_ALREADY_USED");
    db.prepare("UPDATE users SET points=points+? WHERE id=?").run(POINTS_PER_REWARD, req.user.id);
    db.prepare("INSERT INTO ledger(user_id,points,reason,reference_id) VALUES(?,?,?,?)")
      .run(req.user.id, POINTS_PER_REWARD, "Rewarded ad (virtual points; browser event)", sessionId);
  });
  try { tx(); } catch (e) {
    if (e.message === "SESSION_ALREADY_USED") return res.status(409).json({ error: "د دې session انعام مخکې کارول شوی." });
    console.error(e); return res.status(500).json({ error: "انعام ثبت نه شو." });
  }
  const user = db.prepare("SELECT email,points FROM users WHERE id=?").get(req.user.id);
  res.json({ pointsAdded: POINTS_PER_REWARD, balance: user.points, note: "مجازی پوائنټونه دي، د پیسو ارزښت نه لري." });
});

app.post("/api/withdrawals", auth, (_req, res) => {
  if (process.env.CASH_WITHDRAWALS_ENABLED !== "true") {
    return res.status(403).json({ error: "واقعي پیسې ایستل غیرفعال دي؛ د خوندي تایید او تادیاتو سیستم لا نه دی بشپړ شوی." });
  }
  return res.status(501).json({ error: "د تادیاتو provider لا نه دی نښلول شوی. د پیسو ایستل مه فعالوه تر څو دا برخه بشپړه او وازمویل شي." });
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => {
  if (!JWT_SECRET || JWT_SECRET.length < 32) console.warn("WARNING: Set a long JWT_SECRET in .env before using this app.");
  console.log(`EarnSmart listening on port ${PORT}; rewarded ads configured: ${adsConfigured}`);
});
