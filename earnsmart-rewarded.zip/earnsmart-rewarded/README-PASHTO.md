# EarnSmart Rewarded Ads (Pashto starter)

دا د EarnSmart د ویب‌سایټ لپاره د Node.js + Express + SQLite بنسټیزه پروژه ده. د Google Ad Manager د GPT Rewarded Ads ویب API کاروي.

## مهم محدودیت
- دا پروژه د تولید لپاره بشپړه تادیاتي/د پیسو ایستلو سیستم نه دی.
- د GPT `rewardedSlotGranted` د براوزر پېښه ده. دا د سرور لپاره کرېپټوګرافیک ثبوت نه دی او په تخنیکي ډول جعل کېدای شي.
- له همدې امله په دې starter کې یوازې مجازي پوائنټونه ثبتېږي؛ د پیسو ایستل قصداً بند دي. د واقعي پیسو تر فعالولو مخکې باید د شبکې له خوا منل شوی server-side verification (که د ټاکل شوي محصول لپاره موجود وي)، د درغلۍ څارنه، د انعامونو حدود، د تادیاتو provider، د کاروونکو تایید، او د محلي قوانینو/محرمیت شرایط بشپړ شي.
- د AdSense عادي اعلانونه د انعام په بدل کې مه کاروه. د Rewarded inventory لپاره باید د Google Ad Manager مناسب setup او د حساب/سایټ تایید موجود وي.
- د GPT rewarded ads یوازې په هغو پاڼو/وسایلو کې ښودل کېږي چې format یې ملاتړ کوي. د اعلان لیدل باید اختیاري وي؛ پر اعلان کلیک کول شرط مه ګرځوه.
- د اعلاناتو د پالیسۍ مطابق، اعلان مه جعلوه، مه اتوماتوه او د impressions/clicks د زیاتولو هڅه مه کوه.

## 1. اړتیاوې
- Node.js 20 یا نوی
- Google Ad Manager حساب او د rewarded web ad unit
- HTTPS hosting د ژوندۍ نسخې لپاره

## 2. نصب
```bash
npm install
cp .env.example .env
```
Windows PowerShell:
```powershell
Copy-Item .env.example .env
```

په `.env` کې:
- `JWT_SECRET`: لږ تر لږه 32 تصادفي توري؛ د production لپاره یو قوي secret وکاروه.
- `GAM_NETWORK_CODE`: د خپل Ad Manager network code.
- `GAM_REWARDED_AD_UNIT_PATH`: د خپل rewarded web ad unit path، عموماً د `/network-code/ad-unit-name` په بڼه. د خپل حساب دقیق مقدار وکاروه.
- `CASH_WITHDRAWALS_ENABLED=false` همداسې پرېږده.

بیا:
```bash
npm start
```
براوزر کې `http://localhost:3000` خلاص کړه.

## 3. Google Ad Manager تنظیم
1. د Google Ad Manager حساب جوړ/تایید کړه او د ویب‌سایټ ملکیت/اجازه بشپړه کړه.
2. د ویب inventory لپاره rewarded ad unit او مناسب line items/demand تنظیم کړه.
3. د Google رسمي لارښوونې ولوله:
   - https://support.google.com/admanager/answer/9116812
   - https://developers.google.com/publisher-tag/samples/display-rewarded-ad
4. د network code او ad unit path دقیق مقدارونه په `.env` کې واچوه.
5. په production کې HTTPS، consent/privacy، د هېواد اړوند اړتیاوې، د حساب تایید، او د شبکې پالیسۍ پوره کړه.
6. د حقیقي اعلان خدمت کېدای شي په هره غوښتنه کې اعلان ونه لري. دا عادي ده؛ په دې حالت کې باید انعام ورنه کړل شي.

## 4. امنیت او د تولید لپاره کار
- دا demo JWT په `sessionStorage` کې ساتي؛ د تولید لپاره د `HttpOnly Secure SameSite` cookie-based session یا ورته خوندي طریقه، CSRF دفاع او سخت input validation و ارزوه.
- SQLite د ساده پیل لپاره دی؛ د څو سرورونو/production لپاره managed database، migrations، backups او monitoring وکاروه.
- د سرور `reward_sessions` او ledger تکراري claim محدودوي، خو ځکه چې د ad grant پېښه له براوزر څخه راځي، یوازې دا د cash payout لپاره بسنه نه کوي.
- د کاروونکي انعامونه د شبکې د رسمي پالیسۍ مطابق وټاکه. د انعام په بدل کې د اعلان کلیک مه غوښتنه کوه.
- د `.env` فایل او JWT_SECRET هېڅکله په frontend یا GitHub کې مه خپروه.
- د پیسو ایستلو API اوس 403/501 ځواب ورکوي. د payout provider له بشپړ integration او امنیتي ازموینې پرته دا فیچر مه فعالوه.

## فایلونه
- `public/index.html` — پښتو موبایل-friendly UI
- `public/app.js` — GPT rewarded ad lifecycle، auth UI او claim API
- `server.js` — auth، rate limits، SQLite ledger او reward session endpoints
- `.env.example` — د چاپېریال متغیرونو نمونه
